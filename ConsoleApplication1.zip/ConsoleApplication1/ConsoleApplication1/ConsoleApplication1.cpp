#include <iostream>
#include "Usuario.h"

using namespace std;

int main() {
    string usuario, contrasenia;
     Usuario usuario1("dilanco", "mipassword");
     cout << "Ingresar usuario: ";
     cin >> usuario;
     cout << "Ingresar password: ";
     cin >> contrasenia;
     if((usuario1.Verificarlogin)(usuario, contrasenia))
         cout<<"Acceso exitoso";
     else 
         cout<<"Acceso denegado";
    return 0;
}